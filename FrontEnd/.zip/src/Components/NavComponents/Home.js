import React from 'react'
import Header from '../Header'
import Carousel from '../Carousel'
import About from '../About'

import Footer from '../Footer'
import Content1 from '../HomeComponets/Content1'

import Navbar from '../../Navbar'
import AboutHome from '../HomeComponets/AboutHome'
import Faculties from '../Faculties'
// import Faculties from '../HomeComponets/Faculties'
// import { Navigate, useNavigate } from 'react-router-dom';

const Home = () => {
    return (
        <>
            {/* <Header />
            <Carousel />
            <About />
            <Faculties />
            <Footer/> */}
            <Navbar/>
          
        </>
    )
}

export default Home