import React from 'react'
// import './Faculties.css'
import DefaultImage from '../../Assets/Card.jpg'

const Faculties = () => {
  return (
    <>
    

 
    </>
  )
}

export default Faculties