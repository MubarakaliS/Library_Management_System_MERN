import React from 'react'
import Container from 'react-bootstrap/Container'
import './About.css'
const About = () => {
    return (
        <>
            <section className='container fbn-block about mt-5 p-5 '>
                <div className='container m-3'>
                    <div className='container row justify-content-center'>
                        <div className='col col-md-8 text-center'>
                            <h1>
                                About
                            </h1>
                            <p className='lead'>This is college and i am pursuing in MCA n government arts college from coimbatoreThis is college and i am pursuing in MCA n government arts college from coimbatoreThis is college and i am pursuing in MCA n government arts college from coimbatore</p>
                        </div>
                    </div>

                </div>
            </section>
        </>
    )
}

export default About