import './App.css';
import Header from './Components/Header';
import CarouselView from './Components/Carousel';
import About from './Components/About';
import Faculties from './Components/Faculties';
import LibraryMain from './Components/LibraryModule/LibraryMain';
import AddStudentForm from './Components/LibraryModule/AddStudent';

function App() {
  return (
    <>
      {/* <Header />
      <CarouselView />
      <About/>
      <Faculties/> */}
      {/* <LibraryMain/> */}
      {/* <AddStudentForm/> */}
    </>

  );
}

export default App;

